package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.HttpURLConnection;
import java.net.URL;

public class Controller {

    @FXML
    public TextField firstField;
    @FXML
    public TextField secondField;
    @FXML
    public Label outField;

    public void buttonAction(){
        try {
            HttpURLConnection connection = null;
            connection = (HttpURLConnection) new URL("192.168.1.4/fforward").openConnection();

            connection.setRequestMethod("GET");
            connection.setUseCaches(false);

            connection.connect();


        } catch (Throwable ex) {
            ex.printStackTrace();
        }
            outField.setText("¯\\_(ツ)_/¯");

    }


}
